package br.com.fiap.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.fiap.model.Carro;

public interface CarroRepository extends JpaRepository<Carro, Long> {

}
