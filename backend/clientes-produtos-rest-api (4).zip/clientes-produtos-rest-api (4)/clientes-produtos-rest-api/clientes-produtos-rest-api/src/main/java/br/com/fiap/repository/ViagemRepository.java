package br.com.fiap.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import br.com.fiap.model.Passageiro;
import br.com.fiap.model.Viagem;
import br.com.fiap.model.ViagemInfoDTO;

import java.util.List;

public interface ViagemRepository extends JpaRepository<Viagem, Long> {

    List<Viagem> findByStatus(String status);
    List<Viagem> findByPassageiro(Passageiro passageiro);
}


