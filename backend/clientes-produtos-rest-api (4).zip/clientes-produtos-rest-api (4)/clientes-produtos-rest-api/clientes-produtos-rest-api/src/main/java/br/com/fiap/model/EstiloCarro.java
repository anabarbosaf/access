package br.com.fiap.model;

public enum EstiloCarro {
    SILENCIOSO,
    MAIS_ESPACOSO_COM_RAMPAS_E_APOIOS,
    SEM_RESTRICOES
}





