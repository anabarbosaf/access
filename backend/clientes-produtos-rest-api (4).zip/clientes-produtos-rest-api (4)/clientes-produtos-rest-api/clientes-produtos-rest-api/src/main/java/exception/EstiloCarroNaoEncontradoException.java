package exception;

public class EstiloCarroNaoEncontradoException extends RuntimeException {

    public EstiloCarroNaoEncontradoException(String message) {
        super(message);
    }
}
