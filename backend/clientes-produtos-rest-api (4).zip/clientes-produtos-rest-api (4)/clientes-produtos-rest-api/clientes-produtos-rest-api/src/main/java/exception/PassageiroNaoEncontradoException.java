package exception;

public class PassageiroNaoEncontradoException extends RuntimeException {

    public PassageiroNaoEncontradoException(String message) {
        super(message);
    }
}
