package br.com.fiap.model;

public enum TipoDeficiencia {
    DEFICIENCIA_MOTORA,
    DEFICIENCIA_MENTAL,
    DEFICIENCIA_INTELECTUAL,
    DEFICIENCIA_VISUAL,
    DEFICIENCIA_AUDITIVA
}
