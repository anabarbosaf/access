package br.com.fiap.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="TB_CARRO")
public class Carro {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String placa;
    private int ano;
    private int quantLugares;

    @Enumerated
    private EstiloCarro estiloCarro;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public int getQuantLugares() {
		return quantLugares;
	}

	public void setQuantLugares(int quantLugares) {
		this.quantLugares = quantLugares;
	}

	public EstiloCarro getEstiloCarro() {
		return estiloCarro;
	}

	public void setEstiloCarro(EstiloCarro estiloCarro) {
		this.estiloCarro = estiloCarro;
	}
	
    
}
