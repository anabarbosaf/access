package com.example.projetoford

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
